import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Scanner;

public class BtArraylist {
	// Tao mang dong de luu cac ho ten sinh vien
	public static ArrayList<String> DsHoten= new ArrayList<String>();
	// tao mang dong de luu cac dtb cua sinh vien
	public static ArrayList<Double> DsDtb=new ArrayList<Double>();
	public static ArrayList<String> DsDR=new ArrayList<String>();
	public static void TaoDanhSach() {
		try {
			// Mo file sv.txt luu o thu muc phan 1
			//FileInputStream f=new FileInputStream("sv.txt");
			FileReader f=new FileReader("java.txt");
			//InputStreamReader ir=new InputStreamReader(f);
			BufferedReader r=new BufferedReader(f);
			while(true) {
				// Duyet file
				String st=r.readLine();
				if(st==""|| st==null) break; // neu het file: hoat st="" hoac st=null
				String[] ds=st.split("[;]"); // tach cac thong tin tu st
				DsHoten.add(ds[1]); // them vao mang DsHoten 1 ho  ten
				// them vao mang DsDtb 1 diem trung binh
				DsDtb.add(Double.parseDouble(ds[3]));
				DsDR.add(ds[4]);
			}
			// Dong file
			r.close();
		} catch(Exception tt) {
			System.out.println("Loi o ham Xuat Danh sach:"+ tt.getMessage());
		}
		
	}
	public static void XuatDanhSach() {
		int ss=DsHoten.size(); // Lay do dai cua mang
		for(int i=0; i<ss; i++) {
			System.out.println(DsHoten.get(i)+":"+DsDtb.get(i));
			System.out.println(DsDR.get(i));
		}
	}
	// YEU CAU BO SUNG
	public static void TimKiem() {
		System.out.println("Nhap ten sv");
		Scanner sc=new Scanner(System.in);
		String nhap=sc.nextLine();
		int check=0;
		for(int i=0; i<DsHoten.size();i++) {
			if(DsHoten.get(i).contains(nhap)==true) {
				check=1;
				break;
			}
		}
		if(check==1) {
			System.out.println("Hoc sinh nay ton tai trong danh sach");
		}
		else {
			System.err.println("Hoc sinh nay khong ton tai trong danh sach");
		}	
	}
	public static void ThongKe () {
		int check=0;
		int check1=0;
		for(int i=0; i<DsDR.size();i++) {
			if(DsDR.get(i).equalsIgnoreCase("Dau")==true){
					check++;
					
			}
			else {
				check1++;
			}
		}
		System.out.println("So sv dau la: "+check);
		System.out.println("So sv rot la: "+check1);
	}
	public static void TBC() {
		double sum=0;
		int dem=0;
		for(int i=0; i<DsDtb.size();i++) {
			sum+=(DsDtb.get(i));
			dem++;
		}
		System.out.println("Trung cong cua diem trung binh: "+ sum/dem);
	}
	public static void main(String[] args) {
		TaoDanhSach();
     	XuatDanhSach();
		TimKiem();
		ThongKe();
		TBC();
		
	}

}
