import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Scanner;

public class BtMang {
	public String TaoNgay (String ngay1, String ngay2) {
		try {
			// Dinh dang ngay thro dang ngay thangn nam
			SimpleDateFormat f= new SimpleDateFormat("dd/MM/yyyy");
			Date n1= f.parse(ngay1); // Doi chuoi ngay 1 ra keu ngay
			Date n2= f.parse(ngay2); 
			Random r= new Random(); // Khoi tao ham Random 
			while(true) {
				Long t=r.nextLong(); // Lay 1 so ngau nhien
				// n1.getTime: Doi ngay ra so
				if(t>=n1.getTime()&&t<=n2.getTime()) {
					Date n= new Date(t); // Doi so ra ngay
					return f.format(n); // Tra ve chuoi ngay thang nam
				}
			}
		} catch(Exception tt) {
			System.out.println("Loi: "+ tt.getMessage());
			return null;
		}
	}
	public String TaoHoTen() {
		String [] ho= {
				"Tran", "Le", "Nguyen"
		};
		String [] chulot= {
				"Thanh", "Hoang", "Trung", "Van", "My"
		};
		String [] ten= {
				"Hung", "Nga", "Tien", "Tam", "Ton", "Giang", "Sy"
		};
		Random r= new Random();
		// ho.lenghth tra ve do dai cua mang ho -> 3
		String h=ho[r.nextInt(ho.length)];
		String cl=chulot[r.nextInt(chulot.length)];
		String t=ten[r.nextInt(ten.length)];
		return h+" "+cl+" "+t;
	}
	// YEU CAU BO SUNG
	public String GioiTinh() {
		Random rd= new Random();
		String [] GT= {
				"Nam", "Nu"
		};
		String gt=GT[rd.nextInt(GT.length)];
		return gt;
	}
	public void KetQua(double n) {
		if(n>=5) {
			System.out.println("Dau");
		}
		else {
			System.out.println("Rot");
		}
	}
	public void XepLoai(double n) {
		if(n>=8) {
			System.out.println("Gioi");
		}
		else if (n<=7.9 && n>=6.5) {
			System.out.println("Kha");
		}
		else if (n<=6.4 && n>=5) {
			System.out.println("Trung binh");
		}
		else if (n<=4.9 && n>=3.1) {
			System.out.println("Yeu");
		}
		else {
			System.out.println("Kem");
		}
	}
	public void HienThi(int n) {
		Random r= new Random();
		
		for(int i=1; i<=n; i++) {
			double dtb= r.nextDouble()*10;
			System.out.println(TaoHoTen()+";"+GioiTinh()+";"+TaoNgay("01/01/1960","01/01/2000")+";"+dtb);
			KetQua(dtb);
			XepLoai(dtb);
		}
	}
}
