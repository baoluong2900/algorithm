package Phan1;

import java.util.Scanner;

public class Mang {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BtMang m= new BtMang();
//		String ngay1="01/02/1990";
//		String ngay2="12/12/1992";
/*		for(int i=1; i<=10; i++) {
			System.out.println("Thong tin sinh vien thu "+i);    yêu cầu bổ sung 1
			System.out.println(m.TaoHoTen());
			System.out.println(m.TaoNgay(ngay1, ngay2));
		} */ 
		m.HienThi(10);
		Scanner nhap = new Scanner(System.in);  // yêu cầu bổ sung 2
		System.out.println("Moi ban nhap vao n sinh vien ");
		int n=nhap.nextInt();
		m.HienThi(n);
//		nhap.close();

	}

}
