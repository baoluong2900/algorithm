import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.sql.Time;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Random;
import java.util.Scanner;

public class BtFile {
 static	ArrayList<String> ht= new ArrayList<String>();
 static	ArrayList<String> dem= new ArrayList<String>(); 
 static	ArrayList<Double> tbc= new ArrayList<Double>(); 
 	public static String KetQua(double n) {
		if(n>=5) 
			return "Dau";
		return "Rot";
	}
	public static void TaoDanhSach (int n) {
		try {
			// Tao file sv.txt luu o thu muc Phan1
			FileOutputStream f=new FileOutputStream("java.txt");
			OutputStreamWriter o=new OutputStreamWriter(f);
			PrintWriter w= new PrintWriter(o);
			Random r=new Random();
			// Tao lop BtMang de su dung cac ham ben trong lop nay
			BtMang m=new BtMang();
			for(int i=1; i<=n;i++) {
			// Duyen qua n sinh vien
				double dtb= r.nextDouble()*10; // Tao ngau nhien 1 dtb
				// Ghi vao file ma sv, ho ten, ngay sinh va diem trung binh
				w.print("Sv"+i+";"+m.TaoHoTen()+";"+m.TaoNgay("01/01/1960","01/01/2000")+";"+dtb);
				KetQua(dtb);
				String t=KetQua(dtb);
				w.print(";"+t);			
			}
			// Dong file va luu du lieu
			w.close();
			System.out.println("Da tao xong");
		} catch(Exception tt) {
			System.out.println("Loi o ham TaoDanhSach:" + tt.getMessage());
		}
	}
	public static void XuatDanhSach() {
		try {
			//Mo file sv.txt luu o thu muc Phan1
			FileInputStream f= new FileInputStream("java.txt");
			InputStreamReader ir= new InputStreamReader(f);
			BufferedReader r= new BufferedReader(ir);
			BtMang m=new BtMang();
			while(true) {
				// Duyet filef=
				String st=r.readLine();
				if(st==""||st==null) break;//Neu het file: hoac st="" hoac st=null
				String[] ds=st.split("[;]"); // Tach thong tin tu st
				System.out.println(ds[0]+"\n"+ds[1]+"\n"+ds[2]+"\n"+ds[3]+"\n\n");
				System.out.println(ds[4]);
				ht.add(ds[1]);
				dem.add(ds[4]);
				tbc.add(Double.parseDouble(ds[3]));
				
			}
			// Dong file
			r.close();
		} catch(Exception tt) {
			System.out.println("Loi o ham XuatDanhSach: "+ tt.getMessage());
		}
	}
	public static void Timkiem() {
		
	}
//	 YEU CAU BO SUNG
	public static void TimKiem() {
		System.out.println("Moi ban nhap ten");
		int check=0;
		Scanner sc=new Scanner(System.in);
		String nhap=sc.nextLine();
		for(int i=0;i<ht.size();i++) {
			if(ht.get(i).contains(nhap)==true) {
				check=1;
				break;
			}
		}
		if(check==1) {
			System.out.println("Hoc sinh nay ton tai trong danh sach");
		}
		else
			System.err.println("Hoc sinh nay khong ton tai trong danh sach");
	}
	public static void Dem() {
		int check=0;
		int check1=0;
		for(int i=0; i<dem.size();i++) {
			if(dem.get(i).equalsIgnoreCase("Dau")) {
				check++;
			}
			if(dem.get(i).equalsIgnoreCase("Rot")) {
				check1++;
			}
		}
		System.out.println("So sv dau la :"+check);
		System.out.println("So sv rot la : "+check1);
	}
	public static void TBC() {
		double sum=0;
		int Dem=0;
		for(int i=0;i<tbc.size();i++) {
			sum+=(tbc.get(i));
			Dem++;
		}
		System.out.println("Trung binh cong cua diem trung binh: "+(sum/Dem));	
	}
	public static void main(String[] args) {
//	    TaoDanhSach(3);
        XuatDanhSach();
        TimKiem();
//        Dem();‬
//        TBC();
       
   
	}	


}
