import java.util.Scanner;

public class Mang {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BtMang m= new BtMang();
//		String ngay1="01/02/1990";
//		String ngay2="12/12/1992";
//		System.out.println(m.TaoHoTen());
//		System.out.println(m.TaoNgay(ngay1, ngay2));
/*		for(int i=1; i<=10; i++) {
			System.out.println("Thong tin sinh vien thu "+i);    YÊU CẦU BỔ SUNG Bài 1.b)
			System.out.println(m.TaoHoTen());
			System.out.println(m.TaoNgay(ngay1,ngay2));
		} */
		//  YÊU CẦU BỔ SUNG
//		m.HienThi(10);
		Scanner Nhap=new Scanner(System.in);
		System.out.println("\n Moi ban nhap vao n");
		int n=Nhap.nextInt();
		m.HienThi(n); 

		
	}

}
